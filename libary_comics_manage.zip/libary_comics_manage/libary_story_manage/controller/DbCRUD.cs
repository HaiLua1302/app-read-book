﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libary_story_manage.controller
{
    class DbCRUD
    {
        //Rút trích dữ liêu: SELECT 
        // lấy dữ liệu truyện
        public static DataTable GetDataComics()
        {
            string sql = "SELECT * " +
                "FROM tb_comics " +
                "ORDER BY comics_id ASC; ";
            DataTable dt = DbConnect.ExecuteQuery(sql);
            return dt;
        }
        // lấy dữ liệu tap truyện
        public static DataTable GetDataEpisodeComics(string idComics)
        {
            string sql = string.Format("SELECT * FROM tb_episode " +
                "WHERE comics_id = N'{0}' ORDER BY episode_name ASC;", idComics);
            DataTable dt = DbConnect.ExecuteQuery(sql);
            return dt;
        }

        // lấy dữ liệu thể loại cho combobox
        public static DataTable GetDataStyles()
        {
            string sql = "SELECT * " +
                "FROM tb_styles " +
                "ORDER BY styles_name ASC; ";
            DataTable dt = DbConnect.ExecuteQuery(sql);
            return dt;
        }

        // lấy data comics mới được thêm vào
        public static string GetIdComicsNew()
        {
            string sql = "SELECT AUTO_INCREMENT FROM information_schema.TABLES " +
                "WHERE TABLE_SCHEMA = 'dbtruyen' " +
                "AND TABLE_NAME = 'tb_comics'";
           return DbConnect.get_valueSQL(sql);
        }
        // lấy data tập mới được thêm vào
        public static string GetIdEpisodeComicsNew()
        {
            string sql = "SELECT AUTO_INCREMENT FROM information_schema.TABLES " +
                "WHERE TABLE_SCHEMA = 'dbtruyen' " +
                "AND TABLE_NAME = 'tb_episode'";
            return DbConnect.get_valueSQL(sql);
        }

        //thêm dữ liệu : insert
        //thêm dữ liệu mới cho truyện
        public static bool InsertComics(model.ClsComics cm)
        {
            bool kq;
            string sql = string.Format(" INSERT INTO tb_comics( comics_name, comics_introduce, comics_style, comics_img, comics_cover_img, like_comics, comics_state ,created_at) " +
                "VALUES(N'{0}', N'{1}',N'{2}', N'{3}', N'{4}', N'{5}', N'{6}', N'{7}');",
               cm.Comics_name,cm.Comics_introduce,cm.Comics_style,cm.Comics_img,cm.Comics_cover_img,cm.Like_comics,cm.Comics_state,cm.Created_at);
            kq = DbConnect.ExecuteNonQuery(sql);
            return kq;
        }
        //thêm dữ liệu mới cho tập truyện
        public static bool InsertEpisodeComics(model.ClsEpisode ep)
        {
            bool kq;
            string sql = string.Format(" INSERT INTO tb_episode( episode_name, episode_img, comics_id) " +
                "VALUES(N'{0}', N'{1}',N'{2}');",
             ep.Episode_name,ep.Episode_img,ep.Comics_id);
            kq = DbConnect.ExecuteNonQuery(sql);
            return kq;
        }
        //thêm dữ liệu mới cho thể loại truyện
        public static bool InsertStylesComics(model.ClsStylesComics sc)
        {
            bool kq;
            string sql = string.Format(" INSERT INTO tb_styles( styles_name) " +
                "VALUES(N'{0}');",
             sc.Styles_name);
            kq = DbConnect.ExecuteNonQuery(sql);
            return kq;
        }


        //cập nhật dữ liệu cho data
        //cập nhật thông tin truyện
        public static bool UpdateComics(model.ClsComics cm)
        {
            bool kq;
            string sql = string.Format(" UPDATE tb_comics SET comics_name = N'{0}', comics_introduce = N'{1}', " +
                "comics_style = N'{2}', comics_img = N'{3}', comics_cover_img = N'{4}', like_comics = N'{5}', comics_state = N'{6}' " +
                "WHERE comics_id = N'{7}'",
               cm.Comics_name, cm.Comics_introduce, cm.Comics_style, cm.Comics_img, cm.Comics_cover_img, cm.Like_comics, cm.Comics_state,cm.Comics_id);
            kq = DbConnect.ExecuteNonQuery(sql);
            return kq;
        }
        //cập nhật thông tin tập truyện
        public static bool UpdateEpisodeComics(model.ClsEpisode ep)
        {
            bool kq;
            string sql = string.Format(" UPDATE tb_episode SET episode_name = N'{0}', episode_img = N'{1}' " +
                "WHERE episode_id = N'{2}' AND comics_id = N'{3}'",
               ep.Episode_name,ep.Episode_img,ep.Episode_id,ep.Comics_id);
            kq = DbConnect.ExecuteNonQuery(sql);
            return kq;
        }
        //cập nhật thông tin thể loại truyện
        public static bool UpdateStylesComics(model.ClsStylesComics sc)
        {
            bool kq;
            string sql = string.Format(" UPDATE tb_styles SET styles_name = N'{0}' " +
                "WHERE styles_id = N'{1}'",
               sc.Styles_name,sc.Styles_id);
            kq = DbConnect.ExecuteNonQuery(sql);
            return kq;
        }


        //xoá dữ liệu
        //xoá truyện
        public static bool DeleteComics(model.ClsComics cm)
        {
            bool kq;
            string sql = string.Format("DELETE FROM tb_comics WHERE comics_id = N'{0}'",
               cm.Comics_id);
            kq = DbConnect.ExecuteNonQuery(sql);
            return kq;
        }
        //xoá tập truyện
        public static bool DeleteEpisodeComics(model.ClsComics cm)
        {
            bool kq;
            string sql = string.Format("DELETE FROM tb_episode WHERE comics_id = N'{0}'",
               cm.Comics_id);
            kq = DbConnect.ExecuteNonQuery(sql);
            return kq;
        }
        //xoá tập thể loại truyện
        public static bool DeleteStylesComics(model.ClsStylesComics sc)
        {
            bool kq;
            string sql = string.Format("DELETE FROM tb_styles WHERE styles_id = N'{0}'",
               sc.Styles_id);
            kq = DbConnect.ExecuteNonQuery(sql);
            return kq;
        }

    }
}
