﻿
namespace libary_story_manage
{
    partial class form_story_manage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControlTruyen = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btn_refresh = new System.Windows.Forms.Button();
            this.dtgListComics = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btn_lamMoi = new System.Windows.Forms.Button();
            this.btn_chon_anhbia = new System.Windows.Forms.Button();
            this.pic_biatruyen = new System.Windows.Forms.PictureBox();
            this.lb_duongdan_bia = new System.Windows.Forms.Label();
            this.lb_tenanhbia = new System.Windows.Forms.Label();
            this.btn_chon_anhtruyen = new System.Windows.Forms.Button();
            this.btn_suatruyen = new System.Windows.Forms.Button();
            this.btn_xoatruyen = new System.Windows.Forms.Button();
            this.btn_themtruyen = new System.Windows.Forms.Button();
            this.btn_chitiet_tap = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_trangthai = new System.Windows.Forms.TextBox();
            this.txt_like = new System.Windows.Forms.TextBox();
            this.pic_anhtruyen = new System.Windows.Forms.PictureBox();
            this.lb_duongdan_truyen = new System.Windows.Forms.Label();
            this.txt_gioithieu = new System.Windows.Forms.TextBox();
            this.cb_theloai = new System.Windows.Forms.ComboBox();
            this.txt_tentruyen = new System.Windows.Forms.TextBox();
            this.txt_idtruyen = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lb_tenanh = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_idtruyen = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dtgTheLoai = new System.Windows.Forms.DataGridView();
            this.txtTenTheLoai = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoaTheLoai = new System.Windows.Forms.Button();
            this.btnThemTheLoai = new System.Windows.Forms.Button();
            this.lbIDStyles = new System.Windows.Forms.Label();
            this.tabControlTruyen.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgListComics)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_biatruyen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_anhtruyen)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgTheLoai)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControlTruyen
            // 
            this.tabControlTruyen.Controls.Add(this.tabPage1);
            this.tabControlTruyen.Controls.Add(this.tabPage2);
            this.tabControlTruyen.Controls.Add(this.tabPage3);
            this.tabControlTruyen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlTruyen.Location = new System.Drawing.Point(0, 0);
            this.tabControlTruyen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControlTruyen.Name = "tabControlTruyen";
            this.tabControlTruyen.SelectedIndex = 0;
            this.tabControlTruyen.Size = new System.Drawing.Size(1449, 775);
            this.tabControlTruyen.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.btn_refresh);
            this.tabPage1.Controls.Add(this.dtgListComics);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(1441, 746);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "DS Truyện";
            // 
            // btn_refresh
            // 
            this.btn_refresh.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_refresh.Location = new System.Drawing.Point(3, 2);
            this.btn_refresh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(1435, 33);
            this.btn_refresh.TabIndex = 1;
            this.btn_refresh.Text = "Mới";
            this.btn_refresh.UseVisualStyleBackColor = true;
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // dtgListComics
            // 
            this.dtgListComics.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dtgListComics.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgListComics.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtgListComics.Location = new System.Drawing.Point(3, 2);
            this.dtgListComics.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgListComics.Name = "dtgListComics";
            this.dtgListComics.ReadOnly = true;
            this.dtgListComics.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtgListComics.RowHeadersWidth = 51;
            this.dtgListComics.RowTemplate.Height = 24;
            this.dtgListComics.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgListComics.Size = new System.Drawing.Size(1435, 742);
            this.dtgListComics.TabIndex = 0;
            this.dtgListComics.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgListComics_CellDoubleClick);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tabPage2.Controls.Add(this.btn_lamMoi);
            this.tabPage2.Controls.Add(this.btn_chon_anhbia);
            this.tabPage2.Controls.Add(this.pic_biatruyen);
            this.tabPage2.Controls.Add(this.lb_duongdan_bia);
            this.tabPage2.Controls.Add(this.lb_tenanhbia);
            this.tabPage2.Controls.Add(this.btn_chon_anhtruyen);
            this.tabPage2.Controls.Add(this.btn_suatruyen);
            this.tabPage2.Controls.Add(this.btn_xoatruyen);
            this.tabPage2.Controls.Add(this.btn_themtruyen);
            this.tabPage2.Controls.Add(this.btn_chitiet_tap);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.txt_trangthai);
            this.tabPage2.Controls.Add(this.txt_like);
            this.tabPage2.Controls.Add(this.pic_anhtruyen);
            this.tabPage2.Controls.Add(this.lb_duongdan_truyen);
            this.tabPage2.Controls.Add(this.txt_gioithieu);
            this.tabPage2.Controls.Add(this.cb_theloai);
            this.tabPage2.Controls.Add(this.txt_tentruyen);
            this.tabPage2.Controls.Add(this.txt_idtruyen);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.lb_tenanh);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.lb_idtruyen);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Size = new System.Drawing.Size(1441, 746);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Thông tin chi tiết";
            // 
            // btn_lamMoi
            // 
            this.btn_lamMoi.Location = new System.Drawing.Point(157, 610);
            this.btn_lamMoi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_lamMoi.Name = "btn_lamMoi";
            this.btn_lamMoi.Size = new System.Drawing.Size(75, 30);
            this.btn_lamMoi.TabIndex = 50;
            this.btn_lamMoi.Text = "Mới";
            this.btn_lamMoi.UseVisualStyleBackColor = true;
            this.btn_lamMoi.Click += new System.EventHandler(this.btn_lamMoi_Click);
            // 
            // btn_chon_anhbia
            // 
            this.btn_chon_anhbia.Location = new System.Drawing.Point(851, 366);
            this.btn_chon_anhbia.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_chon_anhbia.Name = "btn_chon_anhbia";
            this.btn_chon_anhbia.Size = new System.Drawing.Size(99, 30);
            this.btn_chon_anhbia.TabIndex = 49;
            this.btn_chon_anhbia.Text = "Chọn ảnh";
            this.btn_chon_anhbia.UseVisualStyleBackColor = true;
            this.btn_chon_anhbia.Click += new System.EventHandler(this.btn_chon_anhbia_Click);
            // 
            // pic_biatruyen
            // 
            this.pic_biatruyen.BackColor = System.Drawing.Color.Silver;
            this.pic_biatruyen.Location = new System.Drawing.Point(851, 400);
            this.pic_biatruyen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pic_biatruyen.MaximumSize = new System.Drawing.Size(251, 250);
            this.pic_biatruyen.Name = "pic_biatruyen";
            this.pic_biatruyen.Size = new System.Drawing.Size(251, 250);
            this.pic_biatruyen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic_biatruyen.TabIndex = 48;
            this.pic_biatruyen.TabStop = false;
            // 
            // lb_duongdan_bia
            // 
            this.lb_duongdan_bia.AutoSize = true;
            this.lb_duongdan_bia.Location = new System.Drawing.Point(847, 654);
            this.lb_duongdan_bia.MaximumSize = new System.Drawing.Size(309, 50);
            this.lb_duongdan_bia.Name = "lb_duongdan_bia";
            this.lb_duongdan_bia.Size = new System.Drawing.Size(41, 17);
            this.lb_duongdan_bia.TabIndex = 47;
            this.lb_duongdan_bia.Text = "// link";
            // 
            // lb_tenanhbia
            // 
            this.lb_tenanhbia.AutoSize = true;
            this.lb_tenanhbia.Location = new System.Drawing.Point(955, 370);
            this.lb_tenanhbia.Name = "lb_tenanhbia";
            this.lb_tenanhbia.Size = new System.Drawing.Size(56, 17);
            this.lb_tenanhbia.TabIndex = 46;
            this.lb_tenanhbia.Text = "Ảnh bìa";
            // 
            // btn_chon_anhtruyen
            // 
            this.btn_chon_anhtruyen.Location = new System.Drawing.Point(851, 10);
            this.btn_chon_anhtruyen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_chon_anhtruyen.Name = "btn_chon_anhtruyen";
            this.btn_chon_anhtruyen.Size = new System.Drawing.Size(99, 30);
            this.btn_chon_anhtruyen.TabIndex = 45;
            this.btn_chon_anhtruyen.Text = "Chọn ảnh";
            this.btn_chon_anhtruyen.UseVisualStyleBackColor = true;
            this.btn_chon_anhtruyen.Click += new System.EventHandler(this.btn_chon_anhtruyen_Click);
            // 
            // btn_suatruyen
            // 
            this.btn_suatruyen.Location = new System.Drawing.Point(504, 610);
            this.btn_suatruyen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_suatruyen.Name = "btn_suatruyen";
            this.btn_suatruyen.Size = new System.Drawing.Size(75, 30);
            this.btn_suatruyen.TabIndex = 44;
            this.btn_suatruyen.Text = "Sửa";
            this.btn_suatruyen.UseVisualStyleBackColor = true;
            this.btn_suatruyen.Click += new System.EventHandler(this.btn_suatruyen_Click);
            // 
            // btn_xoatruyen
            // 
            this.btn_xoatruyen.Location = new System.Drawing.Point(388, 610);
            this.btn_xoatruyen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_xoatruyen.Name = "btn_xoatruyen";
            this.btn_xoatruyen.Size = new System.Drawing.Size(75, 30);
            this.btn_xoatruyen.TabIndex = 43;
            this.btn_xoatruyen.Text = "Xoá";
            this.btn_xoatruyen.UseVisualStyleBackColor = true;
            this.btn_xoatruyen.Click += new System.EventHandler(this.btn_xoatruyen_Click);
            // 
            // btn_themtruyen
            // 
            this.btn_themtruyen.Location = new System.Drawing.Point(273, 610);
            this.btn_themtruyen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_themtruyen.Name = "btn_themtruyen";
            this.btn_themtruyen.Size = new System.Drawing.Size(75, 30);
            this.btn_themtruyen.TabIndex = 42;
            this.btn_themtruyen.Text = "Thêm";
            this.btn_themtruyen.UseVisualStyleBackColor = true;
            this.btn_themtruyen.Click += new System.EventHandler(this.btn_themtruyen_Click);
            // 
            // btn_chitiet_tap
            // 
            this.btn_chitiet_tap.Location = new System.Drawing.Point(157, 500);
            this.btn_chitiet_tap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_chitiet_tap.Name = "btn_chitiet_tap";
            this.btn_chitiet_tap.Size = new System.Drawing.Size(131, 30);
            this.btn_chitiet_tap.TabIndex = 41;
            this.btn_chitiet_tap.Text = "Chi tiết tập truyện";
            this.btn_chitiet_tap.UseVisualStyleBackColor = true;
            this.btn_chitiet_tap.Click += new System.EventHandler(this.btn_chitiet_tap_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(45, 506);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 17);
            this.label9.TabIndex = 40;
            this.label9.Text = "Chi tiết tập";
            // 
            // txt_trangthai
            // 
            this.txt_trangthai.Location = new System.Drawing.Point(157, 458);
            this.txt_trangthai.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_trangthai.Name = "txt_trangthai";
            this.txt_trangthai.Size = new System.Drawing.Size(100, 22);
            this.txt_trangthai.TabIndex = 39;
            // 
            // txt_like
            // 
            this.txt_like.Location = new System.Drawing.Point(157, 415);
            this.txt_like.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_like.Name = "txt_like";
            this.txt_like.Size = new System.Drawing.Size(100, 22);
            this.txt_like.TabIndex = 38;
            this.txt_like.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_like_KeyPress);
            // 
            // pic_anhtruyen
            // 
            this.pic_anhtruyen.BackColor = System.Drawing.Color.LightGray;
            this.pic_anhtruyen.Location = new System.Drawing.Point(851, 46);
            this.pic_anhtruyen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pic_anhtruyen.MaximumSize = new System.Drawing.Size(251, 250);
            this.pic_anhtruyen.Name = "pic_anhtruyen";
            this.pic_anhtruyen.Size = new System.Drawing.Size(251, 250);
            this.pic_anhtruyen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic_anhtruyen.TabIndex = 37;
            this.pic_anhtruyen.TabStop = false;
            // 
            // lb_duongdan_truyen
            // 
            this.lb_duongdan_truyen.AutoSize = true;
            this.lb_duongdan_truyen.Location = new System.Drawing.Point(847, 302);
            this.lb_duongdan_truyen.MaximumSize = new System.Drawing.Size(309, 50);
            this.lb_duongdan_truyen.Name = "lb_duongdan_truyen";
            this.lb_duongdan_truyen.Size = new System.Drawing.Size(41, 17);
            this.lb_duongdan_truyen.TabIndex = 36;
            this.lb_duongdan_truyen.Text = "// link";
            // 
            // txt_gioithieu
            // 
            this.txt_gioithieu.Location = new System.Drawing.Point(157, 175);
            this.txt_gioithieu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_gioithieu.Multiline = true;
            this.txt_gioithieu.Name = "txt_gioithieu";
            this.txt_gioithieu.Size = new System.Drawing.Size(627, 221);
            this.txt_gioithieu.TabIndex = 35;
            // 
            // cb_theloai
            // 
            this.cb_theloai.FormattingEnabled = true;
            this.cb_theloai.Location = new System.Drawing.Point(157, 130);
            this.cb_theloai.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cb_theloai.Name = "cb_theloai";
            this.cb_theloai.Size = new System.Drawing.Size(121, 24);
            this.cb_theloai.TabIndex = 34;
            // 
            // txt_tentruyen
            // 
            this.txt_tentruyen.Location = new System.Drawing.Point(157, 85);
            this.txt_tentruyen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_tentruyen.Name = "txt_tentruyen";
            this.txt_tentruyen.Size = new System.Drawing.Size(627, 22);
            this.txt_tentruyen.TabIndex = 33;
            // 
            // txt_idtruyen
            // 
            this.txt_idtruyen.Location = new System.Drawing.Point(157, 46);
            this.txt_idtruyen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_idtruyen.Name = "txt_idtruyen";
            this.txt_idtruyen.ReadOnly = true;
            this.txt_idtruyen.Size = new System.Drawing.Size(100, 22);
            this.txt_idtruyen.TabIndex = 32;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(45, 462);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 17);
            this.label7.TabIndex = 31;
            this.label7.Text = "Trạng thái";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(45, 418);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 17);
            this.label6.TabIndex = 30;
            this.label6.Text = "Like";
            // 
            // lb_tenanh
            // 
            this.lb_tenanh.AutoSize = true;
            this.lb_tenanh.Location = new System.Drawing.Point(956, 17);
            this.lb_tenanh.Name = "lb_tenanh";
            this.lb_tenanh.Size = new System.Drawing.Size(77, 17);
            this.lb_tenanh.TabIndex = 29;
            this.lb_tenanh.Text = "Ảnh truyện";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 17);
            this.label4.TabIndex = 28;
            this.label4.Text = "Giới thiệu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 17);
            this.label3.TabIndex = 27;
            this.label3.Text = "Thể loại";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 17);
            this.label2.TabIndex = 26;
            this.label2.Text = "Tên truyện";
            // 
            // lb_idtruyen
            // 
            this.lb_idtruyen.AutoSize = true;
            this.lb_idtruyen.Location = new System.Drawing.Point(45, 46);
            this.lb_idtruyen.Name = "lb_idtruyen";
            this.lb_idtruyen.Size = new System.Drawing.Size(63, 17);
            this.lb_idtruyen.TabIndex = 25;
            this.lb_idtruyen.Text = "id truyện";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lbIDStyles);
            this.tabPage3.Controls.Add(this.dtgTheLoai);
            this.tabPage3.Controls.Add(this.txtTenTheLoai);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Controls.Add(this.btnSua);
            this.tabPage3.Controls.Add(this.btnXoaTheLoai);
            this.tabPage3.Controls.Add(this.btnThemTheLoai);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1441, 746);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Thể Loại Truyện";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dtgTheLoai
            // 
            this.dtgTheLoai.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgTheLoai.Location = new System.Drawing.Point(133, 55);
            this.dtgTheLoai.Name = "dtgTheLoai";
            this.dtgTheLoai.RowHeadersWidth = 51;
            this.dtgTheLoai.RowTemplate.Height = 24;
            this.dtgTheLoai.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgTheLoai.Size = new System.Drawing.Size(1049, 671);
            this.dtgTheLoai.TabIndex = 5;
            this.dtgTheLoai.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgTheLoai_CellDoubleClick);
            // 
            // txtTenTheLoai
            // 
            this.txtTenTheLoai.Location = new System.Drawing.Point(133, 15);
            this.txtTenTheLoai.Name = "txtTenTheLoai";
            this.txtTenTheLoai.Size = new System.Drawing.Size(235, 22);
            this.txtTenTheLoai.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Tên Thể Loại :";
            // 
            // btnSua
            // 
            this.btnSua.Location = new System.Drawing.Point(20, 216);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(75, 39);
            this.btnSua.TabIndex = 2;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnXoaTheLoai
            // 
            this.btnXoaTheLoai.Location = new System.Drawing.Point(20, 134);
            this.btnXoaTheLoai.Name = "btnXoaTheLoai";
            this.btnXoaTheLoai.Size = new System.Drawing.Size(75, 39);
            this.btnXoaTheLoai.TabIndex = 1;
            this.btnXoaTheLoai.Text = "Xoá";
            this.btnXoaTheLoai.UseVisualStyleBackColor = true;
            this.btnXoaTheLoai.Click += new System.EventHandler(this.btnXoaTheLoai_Click);
            // 
            // btnThemTheLoai
            // 
            this.btnThemTheLoai.Location = new System.Drawing.Point(20, 55);
            this.btnThemTheLoai.Name = "btnThemTheLoai";
            this.btnThemTheLoai.Size = new System.Drawing.Size(75, 39);
            this.btnThemTheLoai.TabIndex = 0;
            this.btnThemTheLoai.Text = "Thêm";
            this.btnThemTheLoai.UseVisualStyleBackColor = true;
            this.btnThemTheLoai.Click += new System.EventHandler(this.btnThemTheLoai_Click);
            // 
            // lbIDStyles
            // 
            this.lbIDStyles.AutoSize = true;
            this.lbIDStyles.Location = new System.Drawing.Point(1182, 18);
            this.lbIDStyles.Name = "lbIDStyles";
            this.lbIDStyles.Size = new System.Drawing.Size(0, 17);
            this.lbIDStyles.TabIndex = 6;
            // 
            // form_story_manage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1449, 775);
            this.Controls.Add(this.tabControlTruyen);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "form_story_manage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý truyện";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.form_story_manage_Load);
            this.tabControlTruyen.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgListComics)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_biatruyen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_anhtruyen)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgTheLoai)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlTruyen;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dtgListComics;
        private System.Windows.Forms.Button btn_refresh;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btn_chon_anhbia;
        private System.Windows.Forms.PictureBox pic_biatruyen;
        private System.Windows.Forms.Label lb_duongdan_bia;
        private System.Windows.Forms.Label lb_tenanhbia;
        private System.Windows.Forms.Button btn_chon_anhtruyen;
        private System.Windows.Forms.Button btn_suatruyen;
        private System.Windows.Forms.Button btn_xoatruyen;
        private System.Windows.Forms.Button btn_themtruyen;
        private System.Windows.Forms.Button btn_chitiet_tap;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_trangthai;
        private System.Windows.Forms.TextBox txt_like;
        private System.Windows.Forms.PictureBox pic_anhtruyen;
        private System.Windows.Forms.Label lb_duongdan_truyen;
        private System.Windows.Forms.TextBox txt_gioithieu;
        private System.Windows.Forms.ComboBox cb_theloai;
        private System.Windows.Forms.TextBox txt_tentruyen;
        private System.Windows.Forms.TextBox txt_idtruyen;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lb_tenanh;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_idtruyen;
        private System.Windows.Forms.Button btn_lamMoi;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dtgTheLoai;
        private System.Windows.Forms.TextBox txtTenTheLoai;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoaTheLoai;
        private System.Windows.Forms.Button btnThemTheLoai;
        private System.Windows.Forms.Label lbIDStyles;
    }
}

