﻿
namespace libary_story_manage
{
    partial class episode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.lbIDTruyen = new System.Windows.Forms.Label();
            this.tabPageDSTap = new System.Windows.Forms.TabPage();
            this.btnLamMoiDSTap = new System.Windows.Forms.Button();
            this.dtgDsTap = new System.Windows.Forms.DataGridView();
            this.tabDanhSachTap = new System.Windows.Forms.TabControl();
            this.tabPageThemTap = new System.Windows.Forms.TabPage();
            this.btnCapNhatTap = new System.Windows.Forms.Button();
            this.lbIDTap = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnLamMoiTap = new System.Windows.Forms.Button();
            this.btnLuuAnhTap = new System.Windows.Forms.Button();
            this.panelAnhTap = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTenTap = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAnhTap = new System.Windows.Forms.Button();
            this.tabPageDSTap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgDsTap)).BeginInit();
            this.tabDanhSachTap.SuspendLayout();
            this.tabPageThemTap.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1096, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 17);
            this.label3.TabIndex = 18;
            this.label3.Text = "ID Truyện :";
            // 
            // lbIDTruyen
            // 
            this.lbIDTruyen.AutoSize = true;
            this.lbIDTruyen.Location = new System.Drawing.Point(1181, 11);
            this.lbIDTruyen.Name = "lbIDTruyen";
            this.lbIDTruyen.Size = new System.Drawing.Size(44, 17);
            this.lbIDTruyen.TabIndex = 19;
            this.lbIDTruyen.Text = "NULL";
            // 
            // tabPageDSTap
            // 
            this.tabPageDSTap.Controls.Add(this.btnLamMoiDSTap);
            this.tabPageDSTap.Controls.Add(this.dtgDsTap);
            this.tabPageDSTap.Location = new System.Drawing.Point(4, 25);
            this.tabPageDSTap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageDSTap.Name = "tabPageDSTap";
            this.tabPageDSTap.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageDSTap.Size = new System.Drawing.Size(1213, 772);
            this.tabPageDSTap.TabIndex = 0;
            this.tabPageDSTap.Text = "Danh sách tập truyện";
            this.tabPageDSTap.UseVisualStyleBackColor = true;
            // 
            // btnLamMoiDSTap
            // 
            this.btnLamMoiDSTap.Location = new System.Drawing.Point(5, 6);
            this.btnLamMoiDSTap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLamMoiDSTap.Name = "btnLamMoiDSTap";
            this.btnLamMoiDSTap.Size = new System.Drawing.Size(83, 36);
            this.btnLamMoiDSTap.TabIndex = 2;
            this.btnLamMoiDSTap.Text = "Làm Mới";
            this.btnLamMoiDSTap.UseVisualStyleBackColor = true;
            this.btnLamMoiDSTap.Click += new System.EventHandler(this.btnLamMoiDSTap_Click);
            // 
            // dtgDsTap
            // 
            this.dtgDsTap.AllowUserToAddRows = false;
            this.dtgDsTap.AllowUserToDeleteRows = false;
            this.dtgDsTap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgDsTap.Location = new System.Drawing.Point(5, 48);
            this.dtgDsTap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgDsTap.Name = "dtgDsTap";
            this.dtgDsTap.RowHeadersWidth = 51;
            this.dtgDsTap.RowTemplate.Height = 24;
            this.dtgDsTap.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgDsTap.Size = new System.Drawing.Size(1201, 716);
            this.dtgDsTap.TabIndex = 0;
            this.dtgDsTap.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgDsTap_CellDoubleClick);
            // 
            // tabDanhSachTap
            // 
            this.tabDanhSachTap.Controls.Add(this.tabPageDSTap);
            this.tabDanhSachTap.Controls.Add(this.tabPageThemTap);
            this.tabDanhSachTap.Location = new System.Drawing.Point(13, 11);
            this.tabDanhSachTap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabDanhSachTap.Name = "tabDanhSachTap";
            this.tabDanhSachTap.SelectedIndex = 0;
            this.tabDanhSachTap.Size = new System.Drawing.Size(1221, 801);
            this.tabDanhSachTap.TabIndex = 0;
            // 
            // tabPageThemTap
            // 
            this.tabPageThemTap.Controls.Add(this.btnCapNhatTap);
            this.tabPageThemTap.Controls.Add(this.lbIDTap);
            this.tabPageThemTap.Controls.Add(this.label4);
            this.tabPageThemTap.Controls.Add(this.btnLamMoiTap);
            this.tabPageThemTap.Controls.Add(this.btnLuuAnhTap);
            this.tabPageThemTap.Controls.Add(this.panelAnhTap);
            this.tabPageThemTap.Controls.Add(this.label2);
            this.tabPageThemTap.Controls.Add(this.txtTenTap);
            this.tabPageThemTap.Controls.Add(this.label1);
            this.tabPageThemTap.Controls.Add(this.btnAnhTap);
            this.tabPageThemTap.Location = new System.Drawing.Point(4, 25);
            this.tabPageThemTap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageThemTap.Name = "tabPageThemTap";
            this.tabPageThemTap.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageThemTap.Size = new System.Drawing.Size(1213, 772);
            this.tabPageThemTap.TabIndex = 1;
            this.tabPageThemTap.Text = "Thêm Tập";
            this.tabPageThemTap.UseVisualStyleBackColor = true;
            // 
            // btnCapNhatTap
            // 
            this.btnCapNhatTap.Location = new System.Drawing.Point(300, 84);
            this.btnCapNhatTap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCapNhatTap.Name = "btnCapNhatTap";
            this.btnCapNhatTap.Size = new System.Drawing.Size(103, 38);
            this.btnCapNhatTap.TabIndex = 18;
            this.btnCapNhatTap.Text = "Cập nhật";
            this.btnCapNhatTap.UseVisualStyleBackColor = true;
            this.btnCapNhatTap.Click += new System.EventHandler(this.btnCapNhatTap_Click);
            // 
            // lbIDTap
            // 
            this.lbIDTap.AutoSize = true;
            this.lbIDTap.Location = new System.Drawing.Point(80, 15);
            this.lbIDTap.Name = "lbIDTap";
            this.lbIDTap.Size = new System.Drawing.Size(44, 17);
            this.lbIDTap.TabIndex = 17;
            this.lbIDTap.Text = "NULL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 17);
            this.label4.TabIndex = 16;
            this.label4.Text = "ID Tập :";
            // 
            // btnLamMoiTap
            // 
            this.btnLamMoiTap.Location = new System.Drawing.Point(156, 84);
            this.btnLamMoiTap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLamMoiTap.Name = "btnLamMoiTap";
            this.btnLamMoiTap.Size = new System.Drawing.Size(103, 38);
            this.btnLamMoiTap.TabIndex = 15;
            this.btnLamMoiTap.Text = "Mới";
            this.btnLamMoiTap.UseVisualStyleBackColor = true;
            this.btnLamMoiTap.Click += new System.EventHandler(this.btnLamMoiTap_Click);
            // 
            // btnLuuAnhTap
            // 
            this.btnLuuAnhTap.Location = new System.Drawing.Point(17, 84);
            this.btnLuuAnhTap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLuuAnhTap.Name = "btnLuuAnhTap";
            this.btnLuuAnhTap.Size = new System.Drawing.Size(103, 38);
            this.btnLuuAnhTap.TabIndex = 14;
            this.btnLuuAnhTap.Text = "Lưu";
            this.btnLuuAnhTap.UseVisualStyleBackColor = true;
            this.btnLuuAnhTap.Click += new System.EventHandler(this.btnLuuAnhTap_Click_1);
            // 
            // panelAnhTap
            // 
            this.panelAnhTap.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panelAnhTap.Location = new System.Drawing.Point(13, 127);
            this.panelAnhTap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panelAnhTap.Name = "panelAnhTap";
            this.panelAnhTap.Size = new System.Drawing.Size(1185, 635);
            this.panelAnhTap.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(391, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "Chọn hình ảnh tập";
            // 
            // txtTenTap
            // 
            this.txtTenTap.Location = new System.Drawing.Point(84, 43);
            this.txtTenTap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTenTap.Name = "txtTenTap";
            this.txtTenTap.Size = new System.Drawing.Size(199, 22);
            this.txtTenTap.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "Tập :";
            // 
            // btnAnhTap
            // 
            this.btnAnhTap.Location = new System.Drawing.Point(521, 39);
            this.btnAnhTap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAnhTap.Name = "btnAnhTap";
            this.btnAnhTap.Size = new System.Drawing.Size(103, 38);
            this.btnAnhTap.TabIndex = 9;
            this.btnAnhTap.Text = "Thêm ảnh";
            this.btnAnhTap.UseVisualStyleBackColor = true;
            this.btnAnhTap.Click += new System.EventHandler(this.btnAnhTap_Click);
            // 
            // episode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1243, 814);
            this.Controls.Add(this.lbIDTruyen);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tabDanhSachTap);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "episode";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh sách tập truyện";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.episode_FormClosing);
            this.Load += new System.EventHandler(this.episode_Load);
            this.tabPageDSTap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgDsTap)).EndInit();
            this.tabDanhSachTap.ResumeLayout(false);
            this.tabPageThemTap.ResumeLayout(false);
            this.tabPageThemTap.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbIDTruyen;
        private System.Windows.Forms.TabPage tabPageDSTap;
        private System.Windows.Forms.Button btnLamMoiDSTap;
        private System.Windows.Forms.DataGridView dtgDsTap;
        private System.Windows.Forms.TabControl tabDanhSachTap;
        private System.Windows.Forms.TabPage tabPageThemTap;
        private System.Windows.Forms.Button btnLamMoiTap;
        private System.Windows.Forms.Button btnLuuAnhTap;
        private System.Windows.Forms.Panel panelAnhTap;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTenTap;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAnhTap;
        private System.Windows.Forms.Label lbIDTap;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnCapNhatTap;
    }
}