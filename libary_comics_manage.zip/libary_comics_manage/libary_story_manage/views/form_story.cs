﻿using CloudinaryDotNet;
using CloudinaryDotNet.Actions;
using System.Web;
using libary_story_manage.controller;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace libary_story_manage
{
    
    public partial class form_story_manage : Form
    {
        public static string id_comics = "";
        public form_story_manage()
        {
            InitializeComponent();
            
        }

        private void form_story_manage_Load(object sender, EventArgs e)
        {
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            IsServerConnected(DbConnect._connectionString);
            GetDataComics();
            GetDataCombobox();
            GetDataStylesComics();
            pic_anhtruyen.ImageLocation = "https://banner2.cleanpng.com/20180610/uq/kisspng-logo-comics-aventura-emblem-5b1d4a2b5d7798.2951338415286461873829.jpg";
            pic_biatruyen.ImageLocation = "https://banner2.cleanpng.com/20180610/uq/kisspng-logo-comics-aventura-emblem-5b1d4a2b5d7798.2951338415286461873829.jpg";

        }
        //load dữ liệu truyện vào datagridview
        public void GetDataComics()
        {
            try
            {
                DataTable _dskq = controller.DbCRUD.GetDataComics();
                dtgListComics.DataSource = _dskq;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        //load dữ liệu thể loại truyện vào datagridview
        public void GetDataStylesComics()
        {
            try
            {
                DataTable _dskq = controller.DbCRUD.GetDataStyles();
                dtgTheLoai.DataSource = _dskq;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        //lấy id truyện mới thêm
        public void GetDataIDComics()
        {
            try
            {
                string id = controller.DbCRUD.GetIdComicsNew();
                int id_current = Int32.Parse(id) - 1;
                txt_idtruyen.Text = id_current.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //load dữ liệu truyện vào combo box
        public void GetDataCombobox()
        {
            try
            {
                DataTable _dskq = controller.DbCRUD.GetDataStyles();
                cb_theloai.DataSource = _dskq;
                cb_theloai.DisplayMember = "styles_name";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private static bool IsServerConnected(string connectionString)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
/*                    MessageBox.Show("Kết Nối Server Thành Công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);*/
                    return true;
                }
                catch (MySqlException)
                {
                    MessageBox.Show("Kết Nối Server Thất Bại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Application.Exit();
                    return false;
                }
            }
        }

        //wrap text
        private string WrapText(string myWord)
        {
            //tesy
            int myLimit = 40;
            string[] words = myWord.Split(' ');

            StringBuilder newSentence = new StringBuilder();


            string line = "";
            foreach (string word in words)
            {
                if ((line + word).Length > myLimit)
                {
                    newSentence.AppendLine(line);
                    line = "";
                }

                line += string.Format("{0} ", word);
            }

            if (line.Length > 0)
                newSentence.AppendLine(line);
            return newSentence.ToString();
        }
         //getdata from datagridview
        private void GetDataGridView()
        {
            if(dtgListComics.CurrentRow.Cells[1].Value.ToString() != string.Empty)
            {
                txt_idtruyen.Text = dtgListComics.CurrentRow.Cells[0].Value.ToString();
                txt_tentruyen.Text = dtgListComics.CurrentRow.Cells[1].Value.ToString();
                txt_gioithieu.Text = dtgListComics.CurrentRow.Cells[2].Value.ToString();
                cb_theloai.Text = dtgListComics.CurrentRow.Cells[3].Value.ToString();
                lb_duongdan_truyen.Text = dtgListComics.CurrentRow.Cells[4].Value.ToString();
                lb_duongdan_bia.Text = dtgListComics.CurrentRow.Cells[5].Value.ToString();
                txt_like.Text = dtgListComics.CurrentRow.Cells[6].Value.ToString();
                txt_trangthai.Text = dtgListComics.CurrentRow.Cells[7].Value.ToString();

                pic_anhtruyen.ImageLocation = dtgListComics.CurrentRow.Cells[4].Value.ToString(); 
                pic_biatruyen.ImageLocation = dtgListComics.CurrentRow.Cells[5].Value.ToString(); 

                tabControlTruyen.SelectedIndex = 1;
            }
            else { MessageBox.Show("Dữ liệu trống !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information); }
            
            
        }
        //lam moi data
        private void btn_refresh_Click(object sender, EventArgs e)
        {
            GetDataComics();

        }

      

        private void btn_chon_anhtruyen_Click(object sender, EventArgs e)
        {
            OpenFileDialog opnfd = new OpenFileDialog();
            opnfd.Filter = "Image Files (*.jpg;*.jpeg;.*.gif;)|*.jpg;*.jpeg;.*.gif";
            if (opnfd.ShowDialog() == DialogResult.OK)
            {
                pic_anhtruyen.Image = new Bitmap(opnfd.FileName);
                lb_duongdan_truyen.Text = opnfd.FileName;

            }
        }
        private void btn_chon_anhbia_Click(object sender, EventArgs e)
        {
            OpenFileDialog opnfd = new OpenFileDialog();
            opnfd.Filter = "Image Files (*.jpg;*.jpeg;.*.gif;)|*.jpg;*.jpeg;.*.gif";
            if (opnfd.ShowDialog() == DialogResult.OK)
            {
                pic_biatruyen.Image = new Bitmap(opnfd.FileName);
                lb_duongdan_bia.Text =  opnfd.FileName;

            }
        }

        private void dtgListComics_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
             try
            {
                GetDataGridView();
            }catch(Exception ex) { MessageBox.Show(ex.ToString(),"Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information); };
        }

        //upload image to url
        public static string GetDataURL(string imgFile)
        {
            CloudinaryDotNet.Account account = new CloudinaryDotNet.Account("djeiasb2d", "271765671243467", "1rniKmFUXJ_vH9TpRBcpL4giEQI");

            CloudinaryDotNet.Cloudinary cloudinary = new CloudinaryDotNet.Cloudinary(account);
            CloudinaryDotNet.Actions.ImageUploadParams uploadParams = new CloudinaryDotNet.Actions.ImageUploadParams()
            {
                File = new CloudinaryDotNet.FileDescription(Guid.NewGuid().ToString(), imgFile)
            };

            CloudinaryDotNet.Actions.ImageUploadResult uploadResult = cloudinary.Upload(uploadParams);

            /*string url = cloudinary.Api.UrlImgUp.BuildUrl(publicID + imgFile.Substring(imgFile.LastIndexOf(".")));*/
            string url = cloudinary.Api.UrlImgUp.BuildUrl(String.Format("{0}.{1}", uploadResult.PublicId, uploadResult.Format));
            return url;
        }

        //them du lieu
        private void InsertDataComics()
        {
            model.ClsComics cm = new model.ClsComics();
            cm.Comics_name = txt_tentruyen.Text;
            cm.Comics_introduce = txt_gioithieu.Text;
            cm.Comics_style = cb_theloai.Text;
            cm.Like_comics = txt_like.Text;
            cm.Comics_state = txt_trangthai.Text;
            cm.Comics_img = GetDataURL(lb_duongdan_truyen.Text);
            cm.Comics_cover_img = GetDataURL(lb_duongdan_bia.Text);
            cm.Created_at = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            bool kq = controller.DbCRUD.InsertComics(cm);
            if (kq == true)
            {
                MessageBox.Show("Thêm thành công!!!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetDataIDComics();
                GetDataComics();
            }
            else
            {
                MessageBox.Show("Thêm thất bại!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btn_themtruyen_Click(object sender, EventArgs e)
        {
            InsertDataComics();
        }

        private void txt_like_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

      

        private void btn_suatruyen_Click(object sender, EventArgs e)
        {
            model.ClsComics cm = new model.ClsComics();
            cm.Comics_id = Int32.Parse(txt_idtruyen.Text);
            cm.Comics_name = txt_tentruyen.Text;
            cm.Comics_introduce = txt_gioithieu.Text;
            cm.Comics_style = cb_theloai.Text;
            cm.Like_comics = txt_like.Text;
            cm.Comics_state = txt_trangthai.Text;
            cm.Comics_img = GetDataURL(lb_duongdan_truyen.Text);
            cm.Comics_cover_img = GetDataURL(lb_duongdan_bia.Text);
            try
            {
                bool kq = controller.DbCRUD.UpdateComics(cm);
                Console.WriteLine(kq);
                if (kq == true)
                {
                    MessageBox.Show("Cập nhật thành công!!!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    GetDataComics();
                }
                else
                {
                    MessageBox.Show("Cập nhật thất bại!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch(Exception error) { MessageBox.Show(error.ToString()); }
            
        }

        private void RefreshInfor()
        {
            txt_idtruyen.Text = "";
            txt_tentruyen.Text = "";
            txt_gioithieu.Text = "";
            txt_like.Text = "";
            txt_trangthai.Text = "";
            lb_duongdan_bia.Text = "//";
            lb_duongdan_truyen.Text = "//";
            pic_anhtruyen.ImageLocation = "https://banner2.cleanpng.com/20180610/uq/kisspng-logo-comics-aventura-emblem-5b1d4a2b5d7798.2951338415286461873829.jpg";
            pic_biatruyen.ImageLocation = "https://banner2.cleanpng.com/20180610/uq/kisspng-logo-comics-aventura-emblem-5b1d4a2b5d7798.2951338415286461873829.jpg";

        }
        private void btn_lamMoi_Click(object sender, EventArgs e)
        {
            RefreshInfor();
        }

        //delete image to url
        public static string DelImageCloud(string imgFile)
        {
            CloudinaryDotNet.Account account = new CloudinaryDotNet.Account("djeiasb2d", "271765671243467", "1rniKmFUXJ_vH9TpRBcpL4giEQI");

            CloudinaryDotNet.Cloudinary cloudinary = new CloudinaryDotNet.Cloudinary(account);
            CloudinaryDotNet.Actions.ImageUploadParams uploadParams = new CloudinaryDotNet.Actions.ImageUploadParams()
            {
                File = new CloudinaryDotNet.FileDescription(Guid.NewGuid().ToString(), imgFile)
            };

            CloudinaryDotNet.Actions.ImageUploadResult uploadResult = cloudinary.Upload(uploadParams);

            /*string url = cloudinary.Api.UrlImgUp.BuildUrl(publicID + imgFile.Substring(imgFile.LastIndexOf(".")));*/
            string url = cloudinary.Api.UrlImgUp.BuildUrl(String.Format("{0}.{1}", uploadResult.PublicId, uploadResult.Format));
            return url;
        }
        private void btn_xoatruyen_Click(object sender, EventArgs e)
        {
            model.ClsComics cm = new model.ClsComics();
            cm.Comics_id = Int32.Parse(txt_idtruyen.Text);
            try
            {
                bool kq = controller.DbCRUD.DeleteComics(cm);
                if (kq == true)
                {
                    try
                    {
                        bool kq2 = controller.DbCRUD.DeleteEpisodeComics(cm);
                        Console.WriteLine(kq2);
                        if (kq2 == true)
                        {
                            MessageBox.Show("Xoá truyện thành công!!!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            GetDataComics();
                            RefreshInfor();
                        }
                        else
                        {
                            MessageBox.Show("Xoá truyện thành công!!!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            MessageBox.Show("Danh sách tập trống!Không thể xoá", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            GetDataComics();
                            RefreshInfor();
                        }
                    }
                    catch (Exception error) { MessageBox.Show(error.ToString()); }
                }
                else
                {
                    MessageBox.Show("Cập nhật thất bại!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception error) { MessageBox.Show(error.ToString()); }
        }

        private void btn_chitiet_tap_Click(object sender, EventArgs e)
        {
            episode taptruyen = new episode();
            taptruyen.TopMost = true;
            id_comics = txt_idtruyen.Text;
            taptruyen.Show();
        }

        private void btnThemTheLoai_Click(object sender, EventArgs e)
        {
            model.ClsStylesComics sc = new model.ClsStylesComics();
            sc.Styles_name = txtTenTheLoai.Text;
            try {
                bool kq = controller.DbCRUD.InsertStylesComics(sc);
                if(kq == true)
                {
                    MessageBox.Show("Thêm thể loại : "+sc.Styles_name+ " thành công!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    GetDataStylesComics();
                }
                else { MessageBox.Show("Thêm thất bại!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            } catch (Exception error) { MessageBox.Show(error.ToString()); };
        }

        public void selectStylesFromDgv() {
            lbIDStyles.Text = dtgTheLoai.CurrentRow.Cells[0].Value.ToString();
            txtTenTheLoai.Text = dtgTheLoai.CurrentRow.Cells[1].Value.ToString();
            
        }
        private void btnXoaTheLoai_Click(object sender, EventArgs e)
        {
            model.ClsStylesComics sc = new model.ClsStylesComics();
            sc.Styles_id = Int32.Parse(lbIDStyles.Text);

            try
            {
                bool kq = controller.DbCRUD.DeleteStylesComics(sc);
                if (kq == true)
                {
                    MessageBox.Show("Xoá thể loại : " + txtTenTheLoai.Text + " thành công!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    GetDataStylesComics();
                    txtTenTheLoai.Text = "";
                }
                else { MessageBox.Show("Xoá thất bại!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
            catch (Exception error) { MessageBox.Show(error.ToString()); };
        }

        private void dtgTheLoai_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            selectStylesFromDgv();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            model.ClsStylesComics sc = new model.ClsStylesComics();
            sc.Styles_id = Int32.Parse(lbIDStyles.Text);
            sc.Styles_name = txtTenTheLoai.Text;

            try
            {
                bool kq = controller.DbCRUD.UpdateStylesComics(sc);
                if (kq == true)
                {
                    MessageBox.Show("Cập nhật thể loại : " + txtTenTheLoai.Text + " thành công!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    GetDataStylesComics();
                }
                else { MessageBox.Show("Cập nhật thất bại!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
            catch (Exception error) { MessageBox.Show(error.ToString()); };
        }
    }
}
