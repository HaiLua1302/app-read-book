﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace libary_story_manage
{
    public partial class episode : Form
    {
        public List<string> listImageName = new List<string>();
        public List<string> listImageGetLink = new List<string>();
        public string nameImage = "";
        public string listFileName = "";
        public episode()
        {
            InitializeComponent();
        }

        private void episode_Load(object sender, EventArgs e)
        {
            panelAnhTap.AutoScrollMinSize = new Size(0, 1200);
            lbIDTruyen.Text = form_story_manage.id_comics;
            GetDataEpisodeComics();
        }
        //load dữ liệu tập truyện vào datagridview
        public void GetDataEpisodeComics()
        {
            try
            {
                DataTable _dskq = controller.DbCRUD.GetDataEpisodeComics(form_story_manage.id_comics);
                dtgDsTap.DataSource = _dskq;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        //lấy id truyện mới thêm
        public void GetDataIDEpisodeComics()
        {
            try
            {
                string id = controller.DbCRUD.GetIdEpisodeComicsNew();
                int id_current = Int32.Parse(id) - 1;
                lbIDTap.Text = id_current.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        //upload image to url
        public static string GetDataURL(string imgFile)
        {
            CloudinaryDotNet.Account account = new CloudinaryDotNet.Account("djeiasb2d", "271765671243467", "1rniKmFUXJ_vH9TpRBcpL4giEQI");

            CloudinaryDotNet.Cloudinary cloudinary = new CloudinaryDotNet.Cloudinary(account);
            CloudinaryDotNet.Actions.ImageUploadParams uploadParams = new CloudinaryDotNet.Actions.ImageUploadParams()
            {
                File = new CloudinaryDotNet.FileDescription(Guid.NewGuid().ToString(), imgFile)
            };

            CloudinaryDotNet.Actions.ImageUploadResult uploadResult = cloudinary.Upload(uploadParams);

            /*string url = cloudinary.Api.UrlImgUp.BuildUrl(publicID + imgFile.Substring(imgFile.LastIndexOf(".")));*/
            string url = cloudinary.Api.UrlImgUp.BuildUrl(String.Format("{0}.{1}", uploadResult.PublicId, uploadResult.Format));
            return url;
        }

        private void btnLamMoiDSTap_Click(object sender, EventArgs e)
        {
            GetDataEpisodeComics();
        }

        private void btnLuuAnhTap_Click_1(object sender, EventArgs e)
        {
            foreach (string filesName in listImageName)
            {
                nameImage = GetDataURL(filesName);
                listImageGetLink.Add(nameImage);
            }
            listFileName = String.Join(",",listImageGetLink);
            model.ClsEpisode ep = new model.ClsEpisode();
            ep.Episode_name = txtTenTap.Text;
            ep.Comics_id = lbIDTruyen.Text;
            ep.Episode_img = listFileName;
            try
            {
                bool kq = controller.DbCRUD.InsertEpisodeComics(ep);
                if(kq == true)
                {
                    GetDataIDEpisodeComics();
                    ep.Episode_id = Int32.Parse(lbIDTap.Text);
                    MessageBox.Show("Thêm hình ảnh cho " + ep.Episode_name + " thành công!");
                    GetDataEpisodeComics();
                }
                else
                {
                    MessageBox.Show("Thêm hình ảnh lỗi!");
                }
            }
            catch (Exception error) { MessageBox.Show(error.ToString()); };
        }

        private void btnAnhTap_Click(object sender, EventArgs e)
        {
            
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Chọn ảnh tập truyện";
            ofd.Multiselect = true;
            ofd.Filter = "JPG|*.jpg|JPEG|*.jpeg|PNG|*.png";
            DialogResult dgr = ofd.ShowDialog();
            if (dgr == DialogResult.OK)
            {
                panelAnhTap.Controls.Clear();
                string[] files = ofd.FileNames;
                // Create a List, and it can only contain integers.
                int x = 10;
                int y = 20;
                int maxHeight = -1;
                foreach (string filename in files)
                {
                    PictureBox pic = new PictureBox();
                    pic.SizeMode = PictureBoxSizeMode.Zoom;
                    pic.Size = new System.Drawing.Size(140, 140);
                    pic.Image = Image.FromFile(filename);
                    pic.Location = new Point(x, y);
                    x += pic.Width + 5;
                    maxHeight = Math.Max(pic.Height, maxHeight);
                    if (x > this.ClientSize.Width - 100)
                    {
                        x = 20;
                        y += maxHeight + 10;
                    }
                    this.panelAnhTap.Controls.Add(pic);
                    listImageName.Add(filename);
                }
                /* MessageBox.Show(String.Join(", ", listImageName));*/
            }
        }
        //getdata from datagridview
        private void GetDataGridView()
        {
            try
            {
                panelAnhTap.Controls.Clear();
                if (dtgDsTap.CurrentRow.Cells[1].Value.ToString() != string.Empty)
                {
                    lbIDTap.Text = dtgDsTap.CurrentRow.Cells[0].Value.ToString();
                    txtTenTap.Text = dtgDsTap.CurrentRow.Cells[1].Value.ToString();

                    // Create a List, and it can only contain integers.
                    int x = 10;
                    int y = 20;
                    int maxHeight = -1;
                    string listFileIMGName = dtgDsTap.CurrentRow.Cells[2].Value.ToString();
                    string[] files = listFileIMGName.Split(',');
                    foreach (string filenames in files)
                    {
                        PictureBox pic = new PictureBox();
                        pic.SizeMode = PictureBoxSizeMode.Zoom;
                        pic.Size = new System.Drawing.Size(140, 140);
                        pic.ImageLocation = filenames;
                        pic.Location = new Point(x, y);
                        x += pic.Width + 5;
                        maxHeight = Math.Max(pic.Height, maxHeight);
                        if (x > this.ClientSize.Width - 100)
                        {
                            x = 20;
                            y += maxHeight + 10;
                        }
                        this.panelAnhTap.Controls.Add(pic);

                    }
                    tabDanhSachTap.SelectedIndex = 1;
                }
                else { MessageBox.Show("Dữ liệu trống !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information); }
            }
            catch (Exception error) { MessageBox.Show(error.ToString()); };

        }
        private void dtgDsTap_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            GetDataGridView();
        }

        private void btnLamMoiTap_Click(object sender, EventArgs e)
        {
            txtTenTap.Text = "";
            panelAnhTap.Controls.Clear();
        }

        private void btnCapNhatTap_Click(object sender, EventArgs e)
        {
            foreach (string filesName in listImageName)
            {
                nameImage = GetDataURL(filesName);
                listImageGetLink.Add(nameImage);
            }
            listFileName = String.Join(",", listImageGetLink);
            model.ClsEpisode ep = new model.ClsEpisode();
            ep.Episode_id = Int32.Parse( lbIDTap.Text);
            ep.Episode_name = txtTenTap.Text;
            ep.Comics_id = lbIDTruyen.Text;
            ep.Episode_img = listFileName;

            try
            {
                bool kq = controller.DbCRUD.UpdateEpisodeComics(ep);
                if (kq == true)
                {
                    GetDataIDEpisodeComics();
                    ep.Episode_id = Int32.Parse(lbIDTap.Text);
                    MessageBox.Show("Cập nhật hình ảnh cho " + ep.Episode_name + " thành công!");
                    GetDataEpisodeComics();
                }
                else
                {
                    MessageBox.Show("Cập nhật hình ảnh lỗi!");
                }
            }
            catch (Exception error) { MessageBox.Show(error.ToString()); };
        }

        private void episode_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }
    }
}
