﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libary_story_manage.model
{
    class cls_storys
    {
        private int id;
        private string comics_id;
        private string comics_name;
        private string comics_introduce;
        private string comics_style;
        private string comics_img;
        private string comics_cover_img;
        private string like_comics;
        private string comics_state;
    }
}
