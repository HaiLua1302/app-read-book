﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libary_story_manage.model
{
    class ClsEpisode
    {
        private int episode_id;
        private string episode_name;
        private string episode_img;
        private string comics_id;

        public ClsEpisode()
        {
        }

        public ClsEpisode(int episode_id, string episode_name, string episode_img, string comics_id)
        {
            this.episode_id = episode_id;
            this.episode_name = episode_name;
            this.episode_img = episode_img;
            this.comics_id = comics_id;
        }

        public int Episode_id { get => episode_id; set => episode_id = value; }
        public string Episode_name { get => episode_name; set => episode_name = value; }
        public string Episode_img { get => episode_img; set => episode_img = value; }
        public string Comics_id { get => comics_id; set => comics_id = value; }
    }
}
