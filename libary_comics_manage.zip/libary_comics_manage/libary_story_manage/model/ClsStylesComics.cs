﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libary_story_manage.model
{
    class ClsStylesComics
    {
        private int styles_id;
        private string styles_name;

        public ClsStylesComics(int styles_id, string styles_name)
        {
            this.styles_id = styles_id;
            this.styles_name = styles_name;
        }

        public ClsStylesComics()
        {
        }

        public int Styles_id { get => styles_id; set => styles_id = value; }
        public string Styles_name { get => styles_name; set => styles_name = value; }
    }
}
